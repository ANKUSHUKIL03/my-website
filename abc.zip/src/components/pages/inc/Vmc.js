import React from "react";
function Vmc()
{
    return(
        <section className="section bg-light">
         <div className="container">
            <div className="row">
                <div className="col-md-12 mb-4 text-centre">
                    <h2 className="main-heading">vision mission and values</h2>
                    <div className="underline mx-auto "></div>
                </div>    
                <div className="col-md-4 para">
                    <h5>our vision</h5>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto delectus aliquam deserunt autem quae soluta recusandae rerum, voluptatem enim illum!</p>
                    </div>  
                    <div className="col-md-4 para">
                    <h5>our vision</h5>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto delectus aliquam deserunt autem quae soluta recusandae rerum, voluptatem enim illum!</p>
                    </div> 
                    <div className="col-md-4 para">
                    <h5>our vision</h5>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto delectus aliquam deserunt autem quae soluta recusandae rerum, voluptatem enim illum!</p>
                    </div>        
            </div>
            </div>
        </section>
    );
}
export default Vmc;