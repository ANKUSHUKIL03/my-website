import React from "react";

function Contact()
{
    return(
        <div >
              <div className="container">
            <div className="row">
                <div className="col-md-12 text-centre">
                    <h2 className="main-heading">Contact</h2>
                    <div className="underline mx-auto  "> </div>  
                    <p className="para">
                        welcome , How can We help you?
                        you can contact us through email or call us on the number mentioned below,
                        Thankyou
                        
                    </p>

                         
            </div>
            </div>


        </div>

        </div>
    );
}
export default Contact;