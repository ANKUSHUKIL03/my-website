import React from "react";

function About()
{
    return(
        <div >
            <section className="section">
         <div className="container">
            <div className="row">
                <div className="col-md-12 text-centre">
                    <h2 className="main-heading">About</h2>
                    <div className="underline mx-auto  "> </div>  
                    <p className="para">
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequuntur, quasi ullam. Consectetur asperiores porro fuga mollitia fugiat! Voluptate placeat maiores cupiditate in sapiente autem dolorum qui atque. Voluptatum, officia molestiae.
                        
                    </p>

                         
            </div>
            </div>


        </div>
        </section>


        </div>
    );
}
export default About;